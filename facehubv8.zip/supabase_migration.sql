-- =====================================================
-- MIGRATION FACEHUB v8 - Support Multi-Cliniques
-- =====================================================
-- Ce script ajoute le support pour les cliniques multiples
-- Chaque clinique ne peut voir que ses propres patients
-- Les notes/visites affichent qui les a écrites
-- =====================================================

-- 1. Créer la table des cliniques
CREATE TABLE IF NOT EXISTS clinics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address TEXT,
  phone VARCHAR(50),
  email VARCHAR(255),
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id),
  is_active BOOLEAN DEFAULT true
);

-- 2. Ajouter clinic_id aux tables existantes
-- Note: Exécutez ces commandes une par une si certaines colonnes existent déjà

-- Ajouter clinic_id à user_roles
ALTER TABLE user_roles ADD COLUMN IF NOT EXISTS clinic_id UUID REFERENCES clinics(id);

-- Ajouter clinic_id à user_profiles
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS clinic_id UUID REFERENCES clinics(id);

-- Ajouter clinic_id à patients
ALTER TABLE patients ADD COLUMN IF NOT EXISTS clinic_id UUID REFERENCES clinics(id);

-- Ajouter clinic_id à user_requests (pour les nouvelles demandes)
ALTER TABLE user_requests ADD COLUMN IF NOT EXISTS clinic_id UUID REFERENCES clinics(id);

-- 3. Ajouter le nom du praticien aux visites (pour affichage)
ALTER TABLE visits ADD COLUMN IF NOT EXISTS practitioner_name VARCHAR(255);

-- 4. Créer une vue pour récupérer facilement les infos des praticiens
CREATE OR REPLACE VIEW visit_details AS
SELECT 
  v.*,
  COALESCE(up.full_name, 'Praticien inconnu') as practitioner_display_name
FROM visits v
LEFT JOIN user_profiles up ON v.user_id = up.user_id;

-- 5. Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_patients_clinic ON patients(clinic_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_clinic ON user_roles(clinic_id);
CREATE INDEX IF NOT EXISTS idx_visits_user ON visits(user_id);

-- 6. Policies RLS (Row Level Security) pour les cliniques
-- Activer RLS sur la table clinics
ALTER TABLE clinics ENABLE ROW LEVEL SECURITY;

-- Policy: Les utilisateurs peuvent voir leur propre clinique
CREATE POLICY IF NOT EXISTS "Users can view their own clinic" ON clinics
  FOR SELECT USING (
    id IN (
      SELECT clinic_id FROM user_roles WHERE user_id = auth.uid()
    )
  );

-- Policy: Super admins peuvent tout voir
CREATE POLICY IF NOT EXISTS "Super admins can view all clinics" ON clinics
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'super_admin'
    )
  );

-- 7. Policies RLS pour les patients (filtrer par clinique)
-- D'abord, supprimer les anciennes policies si elles existent
DROP POLICY IF EXISTS "Users can view patients from their clinic" ON patients;
DROP POLICY IF EXISTS "Users can insert patients in their clinic" ON patients;
DROP POLICY IF EXISTS "Users can update patients in their clinic" ON patients;

-- Créer les nouvelles policies
CREATE POLICY "Users can view patients from their clinic" ON patients
  FOR SELECT USING (
    clinic_id IN (
      SELECT clinic_id FROM user_roles WHERE user_id = auth.uid()
    )
    OR 
    clinic_id IS NULL -- Pour la rétrocompatibilité
  );

CREATE POLICY "Users can insert patients in their clinic" ON patients
  FOR INSERT WITH CHECK (
    clinic_id IN (
      SELECT clinic_id FROM user_roles WHERE user_id = auth.uid()
    )
    OR 
    clinic_id IS NULL
  );

CREATE POLICY "Users can update patients in their clinic" ON patients
  FOR UPDATE USING (
    clinic_id IN (
      SELECT clinic_id FROM user_roles WHERE user_id = auth.uid()
    )
    OR 
    clinic_id IS NULL
  );

-- 8. Fonction pour obtenir la clinic_id de l'utilisateur courant
CREATE OR REPLACE FUNCTION get_user_clinic_id()
RETURNS UUID AS $$
  SELECT clinic_id FROM user_roles WHERE user_id = auth.uid() LIMIT 1;
$$ LANGUAGE sql SECURITY DEFINER;

-- 9. Fonction pour créer une clinique avec son premier admin
CREATE OR REPLACE FUNCTION create_clinic_with_admin(
  p_clinic_name VARCHAR(255),
  p_user_id UUID,
  p_user_email VARCHAR(255)
)
RETURNS UUID AS $$
DECLARE
  v_clinic_id UUID;
BEGIN
  -- Créer la clinique
  INSERT INTO clinics (name, created_by)
  VALUES (p_clinic_name, p_user_id)
  RETURNING id INTO v_clinic_id;
  
  -- Mettre à jour le user_role avec la clinique
  UPDATE user_roles 
  SET clinic_id = v_clinic_id
  WHERE user_id = p_user_id;
  
  -- Mettre à jour le user_profile avec la clinique
  UPDATE user_profiles 
  SET clinic_id = v_clinic_id
  WHERE user_id = p_user_id;
  
  RETURN v_clinic_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- MIGRATION DES DONNÉES EXISTANTES
-- =====================================================
-- Si vous avez déjà des données, exécutez ceci pour les migrer:

-- Créer une clinique par défaut pour les données existantes
DO $$
DECLARE
  default_clinic_id UUID;
BEGIN
  -- Vérifier s'il y a des patients sans clinic_id
  IF EXISTS (SELECT 1 FROM patients WHERE clinic_id IS NULL) THEN
    -- Créer une clinique par défaut
    INSERT INTO clinics (name)
    VALUES ('Clinique par défaut')
    RETURNING id INTO default_clinic_id;
    
    -- Assigner tous les patients orphelins à cette clinique
    UPDATE patients SET clinic_id = default_clinic_id WHERE clinic_id IS NULL;
    
    -- Assigner tous les utilisateurs orphelins à cette clinique
    UPDATE user_roles SET clinic_id = default_clinic_id WHERE clinic_id IS NULL;
    UPDATE user_profiles SET clinic_id = default_clinic_id WHERE clinic_id IS NULL;
    
    RAISE NOTICE 'Migration effectuée. Clinique par défaut créée: %', default_clinic_id;
  END IF;
END $$;

-- =====================================================
-- FIN DE LA MIGRATION
-- =====================================================
